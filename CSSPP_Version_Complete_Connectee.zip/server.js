require("dotenv").config?.();
const express=require("express");
const path=require("path");
const fs=require("fs");
const Database=require("better-sqlite3");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const multer=require("multer");
const webpush=require("web-push");

const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||"DEV_ONLY_CHANGE_ME";
const db=new Database(path.join(__dirname,"csspp.db"));
db.pragma("foreign_keys = ON");
db.exec(fs.readFileSync(path.join(__dirname,"schema.sql"),"utf8"));

const adminEmail=process.env.ADMIN_EMAIL||"admin@csspp.local";
const adminPassword=process.env.ADMIN_PASSWORD||"ChangezMoi123!";
if(!db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail)){
  db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")
    .run("Administrateur C.S.S.P.P",adminEmail,bcrypt.hashSync(adminPassword,12),"admin");
}
const upload=multer({dest:path.join(__dirname,"uploads"),limits:{fileSize:10*1024*1024}});
const app=express();
app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use("/uploads",express.static(path.join(__dirname,"uploads")));
app.use(express.static(path.join(__dirname,"public")));

if(process.env.VAPID_PUBLIC_KEY&&process.env.VAPID_PRIVATE_KEY){
  webpush.setVapidDetails(process.env.VAPID_SUBJECT||"mailto:admin@csspp.local",process.env.VAPID_PUBLIC_KEY,process.env.VAPID_PRIVATE_KEY);
}

function tokenFor(u){return jwt.sign({id:u.id,name:u.name,email:u.email,role:u.role,className:u.class_name||""},JWT_SECRET,{expiresIn:"7d"})}
function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Connexion requise"});
  try{req.user=jwt.verify(h.slice(7),JWT_SECRET);next()}catch(e){return res.status(401).json({error:"Session expirée"})}
}
function roles(...allowed){return (req,res,next)=>allowed.includes(req.user.role)?next():res.status(403).json({error:"Accès refusé"})}
function canPost(role){return ["admin","teacher"].includes(role)}
function notifyAll(payload){
  if(!process.env.VAPID_PUBLIC_KEY||!process.env.VAPID_PRIVATE_KEY) return;
  const subs=db.prepare("SELECT * FROM push_subscriptions").all();
  for(const s of subs){
    webpush.sendNotification({endpoint:s.endpoint,keys:{p256dh:s.p256dh,auth:s.auth}},JSON.stringify(payload))
      .catch(()=>db.prepare("DELETE FROM push_subscriptions WHERE id=?").run(s.id));
  }
}

app.get("/api/health",(req,res)=>res.json({ok:true,app:"C.S.S.P.P"}));

app.post("/api/auth/register",async(req,res)=>{
  const {name,email,password,role="parent",className=""}=req.body||{};
  if(!name||!email||!password) return res.status(400).json({error:"Nom, email et mot de passe requis"});
  if(!["parent","student"].includes(role)) return res.status(400).json({error:"Rôle non autorisé à l'inscription publique"});
  try{
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare("INSERT INTO users(name,email,password_hash,role,class_name) VALUES(?,?,?,?,?)")
      .run(name,email.toLowerCase(),hash,role,className);
    const u=db.prepare("SELECT id,name,email,role,class_name FROM users WHERE id=?").get(info.lastInsertRowid);
    res.json({token:tokenFor(u),user:u});
  }catch(e){res.status(400).json({error:"Cette adresse e-mail est déjà utilisée"})}
});
app.post("/api/auth/login",(req,res)=>{
  const {email,password}=req.body||{};
  const u=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").toLowerCase());
  if(!u||!bcrypt.compareSync(password||"",u.password_hash)) return res.status(401).json({error:"Identifiants incorrects"});
  const safe={id:u.id,name:u.name,email:u.email,role:u.role,class_name:u.class_name||""};
  res.json({token:tokenFor(safe),user:safe});
});
app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("/api/posts",auth,(req,res)=>res.json(db.prepare(`
 SELECT p.*,u.name author_name FROM posts p LEFT JOIN users u ON u.id=p.author_id
 ORDER BY datetime(p.created_at) DESC`).all()));
app.post("/api/posts",auth,roles("admin","teacher"),(req,res)=>{
  const {type,title,body,dateText="",place=""}=req.body||{};
  if(!["announcement","urgent","event"].includes(type)||!title||!body) return res.status(400).json({error:"Champs obligatoires manquants"});
  const info=db.prepare("INSERT INTO posts(type,title,body,date_text,place,author_id) VALUES(?,?,?,?,?,?)").run(type,title,body,dateText,place,req.user.id);
  const row=db.prepare("SELECT * FROM posts WHERE id=?").get(info.lastInsertRowid);
  notifyAll({title:type==="urgent"?"🚨 Urgence C.S.S.P.P":"📢 C.S.S.P.P",body:title});
  res.json(row);
});
app.delete("/api/posts/:id",auth,roles("admin"),(req,res)=>{db.prepare("DELETE FROM posts WHERE id=?").run(req.params.id);res.json({ok:true})});

app.get("/api/homework",auth,(req,res)=>{
  const all=db.prepare(`SELECT h.*,u.name author_name FROM homework h LEFT JOIN users u ON u.id=h.author_id ORDER BY deadline ASC,datetime(h.created_at) DESC`).all();
  const filtered=req.user.role==="student"||req.user.role==="parent" ? all.filter(x=>!req.user.className||x.class_name===req.user.className) : all;
  res.json(filtered);
});
app.post("/api/homework",auth,roles("admin","teacher"),(req,res)=>{
 const {subject,className,title,body="",deadline}=req.body||{};
 if(!subject||!className||!title||!deadline) return res.status(400).json({error:"Champs obligatoires manquants"});
 const info=db.prepare("INSERT INTO homework(subject,class_name,title,body,deadline,author_id) VALUES(?,?,?,?,?,?)").run(subject,className,title,body,deadline,req.user.id);
 notifyAll({title:"📚 Nouveau devoir",body:`${subject} — ${title}`});
 res.json(db.prepare("SELECT * FROM homework WHERE id=?").get(info.lastInsertRowid));
});
app.delete("/api/homework/:id",auth,roles("admin","teacher"),(req,res)=>{db.prepare("DELETE FROM homework WHERE id=?").run(req.params.id);res.json({ok:true})});

app.get("/api/events",auth,(req,res)=>res.json(db.prepare("SELECT e.*,u.name author_name FROM events e LEFT JOIN users u ON u.id=e.author_id ORDER BY date_text ASC").all()));
app.post("/api/events",auth,roles("admin","teacher"),(req,res)=>{
 const {title,dateText,place="",body=""}=req.body||{};
 if(!title||!dateText) return res.status(400).json({error:"Titre et date requis"});
 const info=db.prepare("INSERT INTO events(title,date_text,place,body,author_id) VALUES(?,?,?,?,?)").run(title,dateText,place,body,req.user.id);
 notifyAll({title:"📅 Nouvel événement",body:title});
 res.json(db.prepare("SELECT * FROM events WHERE id=?").get(info.lastInsertRowid));
});
app.delete("/api/events/:id",auth,roles("admin"),(req,res)=>{db.prepare("DELETE FROM events WHERE id=?").run(req.params.id);res.json({ok:true})});

app.post("/api/suggestions",auth,(req,res)=>{
 const {body,anonymous=false}=req.body||{};
 if(!body) return res.status(400).json({error:"Proposition vide"});
 const info=db.prepare("INSERT INTO suggestions(body,anonymous,author_id) VALUES(?,?,?)").run(body,anonymous?1:0,req.user.id);
 res.json({id:info.lastInsertRowid,ok:true});
});
app.get("/api/suggestions",auth,roles("admin","teacher"),(req,res)=>res.json(db.prepare(`SELECT s.*,CASE WHEN s.anonymous=1 THEN 'Anonyme' ELSE u.name END author_name FROM suggestions s LEFT JOIN users u ON u.id=s.author_id ORDER BY datetime(s.created_at) DESC`).all()));
app.patch("/api/suggestions/:id",auth,roles("admin","teacher"),(req,res)=>{
 const status=["new","reviewed","accepted","rejected"].includes(req.body.status)?req.body.status:"reviewed";
 db.prepare("UPDATE suggestions SET status=? WHERE id=?").run(status,req.params.id);res.json({ok:true});
});

app.post("/api/push/subscribe",auth,(req,res)=>{
 const {endpoint,keys}=req.body||{};
 if(!endpoint||!keys?.p256dh||!keys?.auth) return res.status(400).json({error:"Abonnement invalide"});
 db.prepare(`INSERT INTO push_subscriptions(user_id,endpoint,p256dh,auth) VALUES(?,?,?,?)
 ON CONFLICT(user_id,endpoint) DO UPDATE SET p256dh=excluded.p256dh,auth=excluded.auth`)
 .run(req.user.id,endpoint,keys.p256dh,keys.auth);
 res.json({ok:true});
});

app.get("/api/admin/users",auth,roles("admin"),(req,res)=>res.json(db.prepare("SELECT id,name,email,role,class_name,created_at FROM users ORDER BY id DESC").all()));
app.post("/api/admin/users",auth,roles("admin"),async(req,res)=>{
 const {name,email,password,role,className=""}=req.body||{};
 if(!name||!email||!password||!["admin","teacher","student","parent"].includes(role)) return res.status(400).json({error:"Données invalides"});
 try{
  const hash=await bcrypt.hash(password,12);
  const info=db.prepare("INSERT INTO users(name,email,password_hash,role,class_name) VALUES(?,?,?,?,?)").run(name,email.toLowerCase(),hash,role,className);
  res.json(db.prepare("SELECT id,name,email,role,class_name FROM users WHERE id=?").get(info.lastInsertRowid));
 }catch(e){res.status(400).json({error:"E-mail déjà utilisé"})}
});
app.delete("/api/admin/users/:id",auth,roles("admin"),(req,res)=>{if(Number(req.params.id)===req.user.id)return res.status(400).json({error:"Impossible de supprimer votre compte"});db.prepare("DELETE FROM users WHERE id=?").run(req.params.id);res.json({ok:true})});

app.post("/api/upload",auth,roles("admin","teacher"),upload.single("file"),(req,res)=>{
 if(!req.file)return res.status(400).json({error:"Fichier manquant"});
 res.json({url:`/uploads/${req.file.filename}`,originalName:req.file.originalname});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`C.S.S.P.P lancé sur http://localhost:${PORT}`));
