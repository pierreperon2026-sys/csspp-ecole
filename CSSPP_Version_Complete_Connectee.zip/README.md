# C.S.S.P.P — version complète connectée

Application web installable du **Complexe Scolaire Saint Pierre Peron**.

## Ce qui est inclus

- Authentification sécurisée par e-mail/mot de passe
- Rôles : administration, professeur, élève, parent
- Annonces et urgences
- Devoirs par classe
- Événements
- Propositions des élèves avec option anonyme
- Gestion des utilisateurs par l'administration
- Base de données SQLite
- Téléversement de fichiers
- Notifications push préparées avec Web Push/VAPID
- PWA installable sur téléphone
- Logo et photo du bâtiment fournis par l'école

## Lancer

Installer Node.js 20+ puis :

```bash
npm install
cp .env.example .env
npm start
```

Ouvrir `http://localhost:3000`.

Compte administrateur initial : les valeurs de `ADMIN_EMAIL` et `ADMIN_PASSWORD` du fichier `.env`.
**Changez immédiatement le mot de passe avant une mise en production.**

## Mise en ligne

Déployer ce dossier sur un serveur Node.js avec HTTPS et définir les variables `.env`.
Pour les notifications push, générer des clés VAPID et renseigner `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` et `VAPID_SUBJECT`.

## Important

Cette archive est une application complète côté logiciel, mais elle n'est pas encore publiée sur un domaine et n'a pas de compte serveur fourni par l'école. La connexion à un hébergeur, le domaine HTTPS et les clés de production sont nécessaires pour que parents/professeurs/élèves puissent l'utiliser à distance.
