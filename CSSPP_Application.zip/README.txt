C.S.S.P.P — Application scolaire
=================================

Prototype web/PWA de l'application du Complexe Scolaire Saint Pierre Peron.

Fichiers:
- index.html : application complète
- logo.jpg : logo fourni
- building.jpg : photo du bâtiment fournie

Utilisation:
1. Ouvrir index.html dans un navigateur.
2. Sur téléphone, utiliser "Ajouter à l'écran d'accueil" pour une expérience proche d'une application.

Fonctionnalités de la maquette:
- Accueil
- Annonces
- Devoirs
- Événements
- Propositions des élèves
- Urgence
- Informations sur l'école
- Contacts
- Notifications
- Profils Administration / Professeur / Élève / Parent

Cette première version est un prototype front-end : les données ne sont pas encore synchronisées avec une base de données et les notifications ne sont pas encore connectées à un serveur.
